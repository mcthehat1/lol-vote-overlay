
import { votes } from './vote';

export function GET() {
  return new Response(JSON.stringify({ votes }));
}
