
let votes = {};

export function POST(req) {
  return new Promise((resolve) => {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', () => {
      const { champion } = JSON.parse(body);
      if (!votes[champion]) votes[champion] = 0;
      votes[champion] += 1;
      resolve(new Response(JSON.stringify({ success: true })));
    });
  });
}
